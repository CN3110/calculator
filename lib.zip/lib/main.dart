import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart'; //ompoting maths library
import './widgets/calculator_button.dart'; //imporing caluculator button widget

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Calculator',
      theme: ThemeData(primarySwatch: Colors.blueGrey),
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: const Text('My Calculator'), //for displaying title
        ),
        body: const Calculator(),
      ),
    );
  }
}

class Calculator extends StatefulWidget {
  const Calculator({super.key});

  @override
  State<Calculator> createState() => _CalculatorState();
}

class _CalculatorState extends State<Calculator> {
  String _input = ''; //to get the input string that user visible
  String _calculationInput = ''; //to send the formatted input string for calculation
  String _output = ''; //to show the result or intermediate
  bool _isResultDisplayed = false; //if a result is currently displayed 
  List<String> _history = []; //to store calculations history

//Method: handle button press
  void _onButtonPressed(String label) { 
    setState(() {
      const operators = ['+', '-', 'x', '/', '^'];

      if (_isResultDisplayed) { // to reset calculator if the result is displayed on the calculation box
        _input = '';
        _calculationInput = '';
        _output = '';
        _isResultDisplayed = false;
      }

      if (label == 'AC') {
        _clear(); //to clear all in the dispaly
      } else if (label == '⌫') {
        _delete(); //to delete only the last charachter
      } else if (label == '=') {
        _evaluateFinal();
      } else if (operators.contains(label)) { // cheking whether the last character is not an operator
          if (_input.isNotEmpty && operators.contains(_input[_input.length - 1])) {
          return; 
        }
        _appendOperator(label, label == 'x' ? '*' : label);
      } else if (label == '√') {
        _appendOperator('√', 'sqrt(');  
      } else if (label == '%') {
        _appendOperator('%', '/100');
      } else if (label == '!') {
        _appendFactorial();
      } else if (label == '()') {
        _appendParentheses();
      } else {
        _appendValue(label, label);
      }
    });
  }

  void _clear() {
    _input = '';
    _calculationInput = '';
    _output = '';
    _isResultDisplayed = false;
  }

  void _delete() {
    if (_input.isNotEmpty) {
      _input = _input.substring(0, _input.length - 1);
      _calculationInput = _calculationInput.isNotEmpty
          ? _calculationInput.substring(0, _calculationInput.length - 1)
          : '';
      _evaluateIntermediate();
    }
  }
  //method: Append operators to the input(from the display and calculation strings
  void _appendOperator(String display, String calculation) {
    if (_input.isEmpty || _isLastCharOperator()) return; 

    if (display == '√') {
      _input += display ;
      _calculationInput += 'sqrt(';
    } else {
      _input += display;
      _calculationInput += calculation;
    }
  }

  void _appendParentheses() { //method: handle parantheses inputs
    if (_input.isEmpty) {
      _input += '(';
      _calculationInput += '('; //when the input is empty, then add open paranthesis
    } else {
      int openParentheses = _input.split('(').length - 1;
      int closeParentheses = _input.split(')').length - 1;

      if (openParentheses > closeParentheses && !_isLastCharOperator() && !_input.endsWith('(')) {
        _input += ')';
        _calculationInput += ')';
      } else {
        if (_input.isNotEmpty && !_isLastCharOperator() && !_input.endsWith('(')) {
          _input += '(';
          _calculationInput += '*(';
        } else {
          _input += '(';
          _calculationInput += '(';
        }
      }
    }
  }
  //method: append a number or decimal to the input
  void _appendValue(String display, String calculation) {
    if (display == '.' && _input.endsWith('.')) return; 
    _input += display;
    _calculationInput += calculation;
    _evaluateIntermediate(); //updating intermediate result
  }
  //method: calculate factorial
  void _appendFactorial() {
    if (_input.isEmpty || _isLastCharOperator()) return;

    int number;
    try {
      number = int.parse(_input.split(RegExp(r'[+\-x/^()]')).last);
    } catch (_) {
      _output = 'Format Error';
      return;
    }

    int factorialResult = 1;
    for (int i = 1; i <= number; i++) {
      factorialResult *= i;
    }

    _input += '!';
    _calculationInput = _calculationInput.replaceFirst(
        RegExp(r'[+\-x/^]*\d+$'), factorialResult.toString());
    _evaluateIntermediate();
  }
  //method: to check whether if the last character is an operator
  bool _isLastCharOperator() {
    if (_input.isEmpty) return false;
    const operators = ['+', '-', 'x', '/', '^'];
    return operators.contains(_input[_input.length - 1]);
  }

  void _evaluateIntermediate() {
    try {
      final isNumeric = RegExp(r'^\d*\.?\d*$').hasMatch(_calculationInput);
      if (isNumeric) {
        _output = _input;
        return;
      }

      if (_calculationInput.isNotEmpty) {
        if (_calculationInput.contains('/0')) {
          _output = "Can't divide by 0";
          return; //preventing division by zero
        }

        Parser parser = Parser();
        Expression expression = parser.parse(_calculationInput);
        ContextModel contextModel = ContextModel();
        double result = expression.evaluate(EvaluationType.REAL, contextModel);

        _output = result % 1 == 0 ? result.toInt().toString() : result.toString(); //displaying result
      }
    } catch (_) {
      _output = '';
    }
  }
  //after pressing the '=' then calculate final result
  void _evaluateFinal() {
    if (_calculationInput.isEmpty) {
      setState(() {
        _output = _input;
      });
      return;
    }

    try {
      if (_calculationInput.contains('/0')) {
        setState(() {
          _input = '';
          _calculationInput = '';
          _output = "Can't divide by 0";
        });
        return;
      }

      Parser parser = Parser();
      Expression expression = parser.parse(_calculationInput);
      ContextModel contextModel = ContextModel();
      double result = expression.evaluate(EvaluationType.REAL, contextModel);

      setState(() {
        _input = result % 1 == 0 ? result.toInt().toString() : result.toString();
        _calculationInput = _input;
        _output = '';
        _isResultDisplayed = true;
        _history.add("$_calculationInput = $_output"); //saving to history
      });
    } catch (_) {
      setState(() {
        _output = 'Format Error';
      });
    }
  }

  void _showHistory() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Calculation History'),
          content: SingleChildScrollView(
            child: Column(
              children: _history.reversed.map((item) => ListTile(
                title: Text(item),
                onTap: () {
                  setState(() {
                    _input = item.split('=')[0].trim();
                    _calculationInput = _input;
                    _evaluateIntermediate();
                  });
                  Navigator.of(context).pop();
                },
              )).toList(),
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  @override //building calculator grid UI
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            SizedBox(
              height: 100,
              child: Container(
                padding: const EdgeInsets.only(right: 12),
                alignment: Alignment.centerRight,
                child: Text(
                  _input,
                  style: const TextStyle(fontSize: 30, color: Colors.grey),
                ),
              ),
            ),
            Container(
              padding: const EdgeInsets.all(12),
              alignment: Alignment.centerRight,
              child: Text(
                _output,
                style: TextStyle(
                  fontSize: _output.contains("Error") || _output.contains("Can't")
                      ? 18
                      : 48,
                  color: _output.contains("Error") || _output.contains("Can't")
                      ? Colors.red
                      : Colors.black,
                ),
              ),
            ),

            const SizedBox(height: 10),
        Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                CalculatorButton(
                  label: '√',
                  onPressed: () => _onButtonPressed('√'),
                  width: 70,
                  height: 50,
                  backgroundColor: const Color.fromARGB(255, 220, 230, 240),
                ),
                CalculatorButton(
                  label: 'π',
                  onPressed: () => _onButtonPressed('π'),
                  width: 70,
                  height: 50,
                  backgroundColor: const Color.fromARGB(255, 220, 230, 240),
                ),
                CalculatorButton(
                  label: '^',
                  onPressed: () => _onButtonPressed('^'),
                  width: 70,
                  height: 50,
                  backgroundColor: const Color.fromARGB(255, 220, 230, 240),
                ),
                CalculatorButton(
                  label: '!',
                  onPressed: () => _onButtonPressed('!'),
                  width: 70,
                  height: 50,
                  backgroundColor: const Color.fromARGB(255, 220, 230, 240),
                ),
              ],
            ),
          

        
        
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                CalculatorButton(label: 'AC', onPressed: () => _onButtonPressed('AC'), backgroundColor:Color.fromARGB(255, 154, 252, 193),),
                CalculatorButton(label: '()', onPressed: () => _onButtonPressed('()'), backgroundColor:Color.fromARGB(255, 154, 190, 252),),
                CalculatorButton(label: '%', onPressed: () => _onButtonPressed('%'), backgroundColor:Color.fromARGB(255, 154, 190, 252),),
                CalculatorButton(label: '/', onPressed: () => _onButtonPressed('/'), backgroundColor:Color.fromARGB(255, 154, 190, 252),),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                CalculatorButton(label: '7', onPressed: () => _onButtonPressed('7')),
                CalculatorButton(label: '8', onPressed: () => _onButtonPressed('8')),
                CalculatorButton(label: '9', onPressed: () => _onButtonPressed('9')),
                CalculatorButton(label: 'x', onPressed: () => _onButtonPressed('x'), backgroundColor:Color.fromARGB(255, 154, 190, 252),),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                CalculatorButton(label: '4', onPressed: () => _onButtonPressed('4')),
                CalculatorButton(label: '5', onPressed: () => _onButtonPressed('5')),
                CalculatorButton(label: '6', onPressed: () => _onButtonPressed('6')),
                CalculatorButton(label: '-', onPressed: () => _onButtonPressed('-'), backgroundColor:Color.fromARGB(255, 154, 190, 252),),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                CalculatorButton(label: '1', onPressed: () => _onButtonPressed('1')),
                CalculatorButton(label: '2', onPressed: () => _onButtonPressed('2')),
                CalculatorButton(label: '3', onPressed: () => _onButtonPressed('3')),
                CalculatorButton(label: '+', onPressed: () => _onButtonPressed('+'), backgroundColor:Color.fromARGB(255, 154, 190, 252),),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                CalculatorButton(label: '0', onPressed: () => _onButtonPressed('0')),
                CalculatorButton(label: '.', onPressed: () => _onButtonPressed('.')),
                CalculatorButton(label: '⌫', onPressed: () => _onButtonPressed('⌫')),
                CalculatorButton(label: '=', onPressed: () => _onButtonPressed('='), backgroundColor:Color.fromARGB(255, 165, 154, 252),),
              ],
            ),
          ],
        ),
      ]
    
        
        ),
        Positioned(
          
          right:1,
          child: ElevatedButton(
            onPressed: _showHistory,  // Show history
            child: const Text('History'),
          ),
        ),
      ],
    );
  }
}
